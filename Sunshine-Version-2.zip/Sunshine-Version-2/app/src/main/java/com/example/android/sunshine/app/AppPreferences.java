package com.example.android.sunshine.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.content.res.Resources;
/**
 * Created by akhande on 9/26/2015.
 */
public class AppPreferences {
    private static final String APP_SHARED_PREFS = AppPreferences.class.getSimpleName();
    private Resources _appResources;
    private SharedPreferences _sharedPrefs;

    public AppPreferences(Context context){
        this._sharedPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        this._appResources = context.getResources();
    }

    public String getKeyWhetherLocation(){
        return _sharedPrefs.getString(_appResources.getString(R.string.pref_location_key)
                ,_appResources.getString(R.string.pref_location_default));
    }

    public String getWeatherUnitType(){
        return _sharedPrefs.getString(_appResources.getString(R.string.pref_temp_units_key)
                ,_appResources.getString(R.string.pref_temp_units_default));
    }
}
